#!/bin/sh
clear
echo ""
echo "Appinventor 2 client for Linux by Krupong"
echo "______________________________________"
echo ""
echo "Uninstalling"
sudo rm /usr/bin/aiStarter
sudo rm -rf /usr/bin/appinventor
echo ""
echo "Finished....."
echo ""
