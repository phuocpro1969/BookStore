#!/bin/sh
clear
echo ""
echo "App Inventor 2 client for Linux by Krupong"
echo "To run, type 'aiStarter' from command line"
echo "_________________________________________________"
echo ""
echo "Create directory..."
sudo mkdir /usr/bin/appinventor
echo "Extracting file"
sudo tar -xf ai2starter.tar.gz -C /usr/bin/appinventor
sudo ln -s /usr/bin/appinventor/ai2starter/aiStarter /usr/bin/aiStarter
echo ""
echo "Finished....."
echo ""
echo "Type 'aiStarter' to start"
echo ""
echo ""
