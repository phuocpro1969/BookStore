Ai2 Starter for Linux

How to install.
1. untar using command 
    $tar -xf ai2Linux-1.0.tar.gz

2. change to directory
    $cd ai2Linux

3. to install
    $sudo ./install.sh
    
4. to uninstall
    $sudo ./uninstall.sh